﻿configuration Initialize 
{ 
    
    Import-DscResource -ModuleName xStorage, PSDesiredStateConfiguration

    Node localhost
    {
        
        Script ChangeCDROMDriveLetter 
{
    GetScript = {
        @{
            GetScript = $GetScript
            SetScript = $SetScript
            TestScript = $TestScript
            Result = (Get-CimInstance -ClassName Win32_Volume -Filter "DriveLetter = 'E:'").DriveType -ne 5
        }           
    }
            
    SetScript = {
        Get-CimInstance -ClassName Win32_Volume -Filter "DriveLetter = 'E:'" | Set-CimInstance -Property @{ DriveLetter = "Z:" }
    }

    TestScript = {
        $Status = (Get-CimInstance -ClassName Win32_Volume -Filter "DriveLetter = 'E:'").DriveType -ne 5
        $Status -eq $True
    }
}
        xWaitforDisk Disk2
        {
            DiskNumber = 2
            RetryIntervalSec =$RetryIntervalSec
            RetryCount = $RetryCount
            DependsOn = "[script]ChangeCDROMDriveLetter"
        }

        xDisk dbVolume {
            DiskNumber = 2
            DriveLetter = "E"
            FSLabel = "DB"
            AllocationUnitSize = 64KB
            DependsOn = "[xWaitForDisk]Disk2"
        }

        xWaitforDisk Disk3
        {
            DiskNumber = 3
            RetryIntervalSec =$RetryIntervalSec
            RetryCount = $RetryCount
        }

        xDisk logVolume {
            DiskNumber = 3
            DriveLetter = "F"
            FSLabel = "LOG"
            AllocationUnitSize = 64KB
            DependsOn = "[xWaitForDisk]Disk3"
        }

        xWaitforDisk Disk4
        {
            DiskNumber = 4
            RetryIntervalSec =$RetryIntervalSec
            RetryCount = $RetryCount
        }

        xDisk tempdbVolume {
            DiskNumber = 4
            DriveLetter = "G"
            FSLabel = "TEMPDB"
            AllocationUnitSize = 64KB
            DependsOn = "[xWaitForDisk]Disk4"
        }

        xWaitforDisk Disk5
        {
            DiskNumber = 5
            RetryIntervalSec =$RetryIntervalSec
            RetryCount = $RetryCount
        }

        xDisk backupVolume {
            DiskNumber = 5
            DriveLetter = "H"
            FSLabel = "BACKUP"
            AllocationUnitSize = 64KB
            DependsOn = "[xWaitForDisk]Disk5"
        }
   }
} 