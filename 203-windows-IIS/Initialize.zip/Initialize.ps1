Configuration Initialize
{
  param ($MachineName)

  Node $MachineName
  {

    #Install ASP.NET 3.5
    WindowsFeature installdotNet35 
    {             
        Name = "Net-Framework-Core"
        Ensure = "Present"
    }

    #Install ASP.NET 4.6
    WindowsFeature ASP
    {
      Name = "Web-Asp-Net46"
      Ensure = "Present"
      
    }

    #Install the IIS Role
    WindowsFeature IIS
    {
      Name = "Web-Server"
      Ensure = "Present"
      
    }

    WindowsFeature WebHttpRedirect
    {
        Name = "Web-Http-Redirect"
        Ensure = "Present"
    }

    WindowsFeature WebODBCLogging
    {
        Name = "Web-ODBC-Logging "
        Ensure = "Present"
    }

    WindowsFeature WebIPSecurity
    {
        Name = " Web-IP-Security"
        Ensure = "Present"
    }

    WindowsFeature WebNetExt
    {
        Name = "Web-Net-Ext"
        Ensure = "Present"
    }
    
    WindowsFeature WebNetExt46
    {
        Name = "Web-Net-Ext46"
        Ensure = "Present"
    }

    WindowsFeature WebAspNet46
    {
        Name = "Web-Asp-Net46"
        Ensure = "Present"
    }

    WindowsFeature WebServerManagementConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = "Present"
    }
  }
} 