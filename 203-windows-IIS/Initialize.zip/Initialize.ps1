Configuration Initialize
{
  param ($MachineName)

  Node $MachineName
  {

    #Install ASP.NET 3.5
    WindowsFeature installdotNet35 
    {             
        Name = "Net-Framework-Core"
        Ensure = "Present"
    }

    #Install ASP.NET 4.6
    WindowsFeature ASP
    {
      Name = "Net-Framework-45-ASPNET"
      Ensure = "Present"
      
    }

    #Install the IIS Role
    WindowsFeature IIS
    {
      Name = "Web-Server"
      Ensure = "Present"
      
    }

    WindowsFeature WebHttpRedirect
    {
        Name = "Web-Http-Redirect"
        Ensure = "Present"
    }

    WindowsFeature WebODBCLogging
    {
        Name = "Web-ODBC-Logging"
        Ensure = "Present"
    }

    WindowsFeature WebIPSecurity
    {
        Name = "Web-IP-Security"
        Ensure = "Present"
    }

    WindowsFeature WebNetExt
    {
        Name = "Web-Net-Ext"
        Ensure = "Present"
    }
    
    WindowsFeature WebNetExt46
    {
        Name = "Web-Net-Ext45"
        Ensure = "Present"
    }

    WindowsFeature WebAspNet46
    {
        Name = "Web-Asp-Net45"
        Ensure = "Present"
    }

    WindowsFeature WebServerManagementConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = "Present"
    }
  }
} 