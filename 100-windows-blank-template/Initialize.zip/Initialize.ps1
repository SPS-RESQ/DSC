﻿configuration Initialize 
{ 
    
    Import-DscResource -ModuleName xStorage, PSDesiredStateConfiguration

    Node localhost
    {
        
        Script ChangeCDROMDriveLetter 
{
    GetScript = {
        @{
            GetScript = $GetScript
            SetScript = $SetScript
            TestScript = $TestScript
            Result = (Get-CimInstance -ClassName Win32_Volume -Filter "DriveLetter = 'E:'").DriveType -ne 5
        }           
    }
            
    SetScript = {
        Get-CimInstance -ClassName Win32_Volume -Filter "DriveLetter = 'E:'" | Set-CimInstance -Property @{ DriveLetter = "Z:" }
    }

    TestScript = {
        $Status = (Get-CimInstance -ClassName Win32_Volume -Filter "DriveLetter = 'E:'").DriveType -ne 5
        $Status -eq $True
    }
}
        xWaitforDisk Disk2
        {
            DiskNumber = 2
            RetryIntervalSec =$RetryIntervalSec
            RetryCount = $RetryCount
            DependsOn = "[script]ChangeCDROMDriveLetter"
        }

        xDisk ADDataDisk {
            DiskNumber = 2
            DriveLetter = "E"
            DependsOn = "[xWaitForDisk]Disk2"
        }

   }
} 